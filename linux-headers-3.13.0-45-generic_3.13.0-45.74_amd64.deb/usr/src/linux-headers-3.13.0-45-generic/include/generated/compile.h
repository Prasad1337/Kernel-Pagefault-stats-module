/* This file is auto generated, version 74 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#74 SMP Thu Feb 5 19:36:53 PST 2015"
#define LINUX_COMPILE_BY "root"
#define LINUX_COMPILE_HOST "ubuntu"
#define LINUX_COMPILER "gcc version 4.8.2 (Ubuntu 4.8.2-19ubuntu1) "
